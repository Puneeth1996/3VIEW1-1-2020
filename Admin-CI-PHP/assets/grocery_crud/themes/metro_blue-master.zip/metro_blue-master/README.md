metro_blue
==========

Theme for Grocery CRUD
=======================================
modified Datatables theme By Cyber3D,
I wanted to create a theme that looks like jTables.org blue metro has and make it simple to install for others who like it.



works with: grocery-crud-1.4.1

copy this theme to: 'project name'\assets\grocery_crud\themes\metro_blue

Use it in your controller: $crud->set_theme('metro_blue');
