# ReactVR-360-Learning-

For creating the boiler plate files for React VR 


This is are some simple practices exercise on react vr and 360 

npm installl -g react-vr-cli
react-vr init WelcomeToVR

Aug 15th 2019 

Added txt files on the code for 
1 understanding props in react 
2 using cube in react vr


Added 1 How to use sphere and cylinder in react vr more the number of width and height segements, than more smooth is the surface./


Also have added the git ignore file to make the code base for the repository lighter

React 360 
Cmds for setting up react 360 boiler plate code

npm install -g react-360-cli
react-360 init WelcomeTo360

