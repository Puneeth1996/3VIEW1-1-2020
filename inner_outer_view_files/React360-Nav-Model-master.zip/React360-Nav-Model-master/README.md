August 18 2019


React 360 Has navigation through model 


Please navigation should also be worked for the y direction coordinated right now it has only the two directional navigation.